
package inicioprimerejercicio;


public class InicioPrimerEjercicio {

    
    public static void main(String[] args) {
        int num1 = 10;
        long num2 = 8;
        double num3 = 15.5;
        boolean condicion=true;
        String saludo = "Hola chicos!!";
        char letra = 'B';
        
        System.out.println("El numero entero es: "+num1);
        System.out.println("El numero long es: "+num2);
        System.out.println("El numero double es: "+num3);
        System.out.println("La condicion actual es: "+condicion);
        System.out.println("Saluda por favor,  "+saludo);
        System.out.println("La letra es: "+letra);
               
        
    }
    
}
